SUMMARY
Create a simple rolling ball game that teaches you many of the principles of working with Unity. No asset download is required for this project.

OBJECTIVE
Teaches you many of the principles of working with Game Objects, Components, Prefabs, Physics and Scripting.
